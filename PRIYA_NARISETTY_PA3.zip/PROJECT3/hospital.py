import random
import string

class Hospital:
    def __init__(self):
        self.patients = {}

    def add_patient(self, patient):
        self.patients[patient.patient_id] = patient

    def remove_patient(self, patient_id):
        if patient_id in self.patients:
            del self.patients[patient_id]
            print("Patient and associated records removed successfully.")
        else:
            print("Patient not found.")

    def retrieve_patient(self, patient_id):
        if patient_id in self.patients:
            patient = self.patients[patient_id]
            print("Patient information for ID:", patient_id)
            for visit in patient.visits:
                print(f"Visit ID: {visit.visit_id}, Visit Time: {visit.visit_time}")
                print(f"Department: {visit.department}, Chief Complaint: {visit.chief_complaint}")
                print("Notes:")
                for note in visit.notes:
                    print(f"Note ID: {note.note_id}, Note Type: {note.note_type}")
        else:
            print("Patient not found.")

    def count_visits_on_date(self, date):
        total_visits = 0
        for patient in self.patients.values():
            for visit in patient.visits:
                if visit.visit_time.date() == date.date():
                    total_visits += 1
        return total_visits
    def generate_unique_visit_id():
        return ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))


